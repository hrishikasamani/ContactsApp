//
//  Utilities.swift
//  WA5_Samani_2453
//
//  Created by Hrishika Samani on 10/10/24.
//

import Foundation

class Utilities{
    static let types = ["Home", "Work", "Cell"]
}
